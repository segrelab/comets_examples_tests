load 'total_biomass.txt'
plot(total_biomass(:,1),total_biomass(:,2))

xlabel 'time'
ylabel 'biomass'